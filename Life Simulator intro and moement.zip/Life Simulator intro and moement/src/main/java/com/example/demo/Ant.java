package com.example.demo;

import java.lang.reflect.Array;
import java.util.ArrayList;

/*

EXTENSIONS:
    1) Get ant's info when checking if nearby
        a) Do this by passing in array of Ant instead of passing gamegrid


*/
public class Ant extends Bug {
    private int x;
    private int y;

    String loc;
    private long startTime;

    public Ant(int x, int y) {
        this.x = x;
        this.y = y;
        startTime = System.nanoTime();
    }

    public void changeLoc(int[][] gameGrid) {
        int timeout = 0;
        boolean check = false;
        while (!check && timeout < 1000) {
            timeout++;
            int tempx = x;
            int tempy = y;
            if (Math.random() > .5) {
                tempx++;
            } else {
                tempx--;
            }
            if (Math.random() > .5) {
                tempy++;
            } else {
                tempy--;
            }
            if (gameGrid[tempx][tempy] == 0) {
                check = true;
                gameGrid[tempx][tempy] = 1;
                gameGrid[x][y] = 0;
                x = tempx;
                y = tempy;
            }
        }

//          System.out.println("x: " + x);

    }

    public boolean checkNearby(ArrayList<Ant> ants) {
        for (int i = 0; i < ants.size(); i++) {
            if (ants.get(i).getX() >= x - 1 && ants.get(i).getX() < x + 1 && ants.get(i).getY() >= y - 1 &&
                    ants.get(i).getY() <= y + 1 && ants.get(i).getX() != x && ants.get(i).getY() != y) return true;
        }
    }

//    for (int tempX = x - 1; tempX <= x + 1 && tempX < gameGrid.length && tempX > 0; tempX++) {
//        for (int tempY = y - 1; tempY <= y + 1 && tempY < gameGrid[tempX].length && tempY > 0; tempY++) {
//            if (gameGrid[tempX][tempY] == 1 && (tempX != x && tempY != y)) System.out.println("Ant: " + );;
//                (gameGrid[tempX][tempY] == 1) ? ((tempX != x && tempY != y) ? return true : continue) : continue;

    public int getX() {
        return this.x;
    }

    public void resetStartTime() {
        startTime = System.nanoTime();
    }

    public long getStartTime() {
        return startTime;
    }

    public int getY() {
        return this.y;
    }
}
